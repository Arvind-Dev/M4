package example.xml;

public class Contact {}
